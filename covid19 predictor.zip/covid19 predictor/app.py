# -*- coding: utf-8 -*-
"""
Created on Mon Jun 29 10:08:43 2020

@author: suhas
"""

import numpy as np
import pandas as pd
import streamlit as st
import pickle




file = open('covid_prototype.pkl', 'rb')
model = pickle.load(file)

def welcome():
    return 'Stay_Home Stay_Safe'

def predict_class(Age, Fever, BodyPains, RunnyNose, Difficulty_in_Breath):
    pred = model.predict([[Age, Fever, BodyPains, RunnyNose, Difficulty_in_Breath]])
    return pred

def main():
    html_temp = """
    <div style="background-color:cyan;padding:10px">
    <h2 style="color:black;text-align:center;">Covid Symptoms Prediction</h2>
    </div>
    """
  
    st.markdown(html_temp , unsafe_allow_html= True)


    Age = st.slider('Age', 1,100)
    Fever = st.slider('Fever', 96,110)
    BodyPains = st.text_input('Body Pains 0(No)- 1(Yes)'," ")
    RunnyNose = st.text_input('RunnyNose 0(No)-1(Yes)'," ")
    Difficulty_in_Breath = st.text_input('Difficulty_in_Breath 0(No)-1(Yes)'," ")             
    result =""
    if st.button('Predict'):
         result=predict_class(int(Age),int(Fever),int(BodyPains),int(RunnyNose),int(Difficulty_in_Breath))
         if result==0:
             result="Hey mate you are safe,dont have any covid-19 symptoms"
         else:
             result="Sorry,you have covid-19 symptoms, please consult doctor.Stay strong mate"
            
  
    st.success('{}'.format(result))
    if st.button("About"):
        st.text("Stay_Home Stay_safe")


main()

if __name__ == '__main__':
    main()
